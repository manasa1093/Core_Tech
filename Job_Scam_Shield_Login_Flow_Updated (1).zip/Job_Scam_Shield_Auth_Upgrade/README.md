# Job & Internship Scam Shield (authentication upgrade)

## Requirements
- Java 17 or newer
- Maven
- Node.js/npm
- MySQL Server

## MySQL
The application uses `job_scam_shield` and MySQL `root` by default. Change the DB password in `backend/src/main/resources/application.properties` or set environment variables `DB_USERNAME`, `DB_PASSWORD`, and optionally `DB_URL`. The URL includes `allowPublicKeyRetrieval=true` to resolve the connector authentication issue noted during setup.

## Run backend
1. Open a terminal in the `backend` folder.
2. Set the DB password (or edit application.properties; default placeholder is `your_mysql_password`).
3. Run `mvn spring-boot:run`.

## Run frontend
1. Open a second terminal in the `frontend` folder.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the Vite URL (normally http://localhost:5173).

## Authentication and data
- Login/register screens precede the dashboard.
- Accounts are persisted in MySQL; password hashes use BCrypt.
- Authentication uses server-side HTTP sessions; the frontend uses credentialed requests.
- Scans are linked to the authenticated email and each user only sees their own scans.
- The login page can remember the email only in localStorage. Passwords are not saved in localStorage.
- Logout invalidates the server session.

## Current scan limitations
Scan scoring remains a preliminary rules-based assessment. URL submissions are not fetched or externally verified. No AI agent, web reputation provider, or live company verification has been added yet. Treat results as a screening aid, not a guarantee.
