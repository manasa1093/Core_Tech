const API_BASE = "http://localhost:8080/api";
async function request(path,options={}){const r=await fetch(`${API_BASE}${path}`,{credentials:'include',...options,headers:{...(options.headers||{}),...(options.body?{'Content-Type':'application/json'}:{})}});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.message||data.error||`Request failed (${r.status})`);return data;}
export const getScans=()=>request('/scans');
export const createScan=(inputType,content)=>request('/scans',{method:'POST',body:JSON.stringify({inputType,content})});
export const login=(email,password)=>request('/auth/login',{method:'POST',body:JSON.stringify({email,password})});
export const register=(name,email,password)=>request('/auth/register',{method:'POST',body:JSON.stringify({name,email,password})});
export const currentUser=()=>request('/auth/me');
export const logout=()=>request('/auth/logout',{method:'POST'});
