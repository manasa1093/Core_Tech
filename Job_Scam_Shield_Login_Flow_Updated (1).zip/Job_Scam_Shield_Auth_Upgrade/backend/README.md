# Job & Internship Scam Shield — Backend

Spring Boot REST API starter using Java 17, Spring Web, Spring Data JPA, Validation and MySQL.

## Included
- `POST /api/scans` — submit job text or URL for preliminary rule-based screening
- `GET /api/scans` — list saved scans
- `GET /api/scans/{id}` — retrieve one saved scan
- MySQL persistence via JPA
- CORS configured for Vite at `localhost:5173`

## Run
1. Install JDK 17+ and Maven.
2. Create the database in MySQL:
   ```sql
   CREATE DATABASE job_scam_shield;
   ```
3. Edit `src/main/resources/application.properties` and set your MySQL username/password, or set `DB_URL`, `DB_USERNAME`, and `DB_PASSWORD` environment variables.
4. From this project folder:
   ```bash
   mvn spring-boot:run
   ```
5. API base URL: `http://localhost:8080`

## Test with JSON
POST `http://localhost:8080/api/scans`
Content-Type: `application/json`
```json
{
  "inputType": "TEXT",
  "content": "We offer a guaranteed job. Pay a registration fee to apply."
}
```
For a URL, use `"inputType": "URL"` and a value beginning with `http://` or `https://`.

## Important limitations
The included `RiskAnalysisService` is a simple demonstration rules engine, not an AI model and not a validated scam detector. URL inputs are only checked for basic URL format; no external reputation API is called yet. Spring AI, real external verification APIs, authentication and user-specific scan ownership are planned follow-up modules. Do not treat a LOW result as proof that a job is genuine.

Never commit real database passwords or API keys to GitHub.
