package com.shield.jobscam.service;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class RiskAnalysisService {
    // Temporary baseline only. We will replace/enrich this with Spring AI and verification APIs.
    public Analysis analyze(String content) {
        String text = content.toLowerCase(Locale.ROOT);
        List<String> findings = new ArrayList<>();
        String[][] rules = {
            {"registration fee", "Requests a registration fee"},
            {"processing fee", "Requests a processing fee"},
            {"security deposit", "Mentions a security deposit"},
            {"pay to apply", "Asks the applicant to pay to apply"},
            {"guaranteed job", "Promises a guaranteed job"},
            {"no interview", "Claims selection without an interview"},
            {"whatsapp", "Uses WhatsApp as a contact channel"},
            {"telegram", "Uses Telegram as a contact channel"},
            {"urgent", "Uses urgency or pressure language"}
        };
        for (String[] rule : rules) {
            if (text.contains(rule[0])) findings.add(rule[1]);
        }
        int score = Math.min(95, findings.size() * 15);
        String level = score >= 60 ? "HIGH" : score >= 30 ? "MODERATE" : "LOW";
        if (findings.isEmpty()) {
            findings.add("No configured warning phrases were found. This does not prove the opportunity is legitimate.");
        }
        String explanation = "Preliminary rule-based screening only. Verify the employer independently before sharing personal information or paying money.";
        return new Analysis(score, level, findings, explanation);
    }

    public record Analysis(int score, String level, List<String> findings, String explanation) {}
}
