package com.shield.jobscam.service;

import com.shield.jobscam.dto.ScanRequest;
import com.shield.jobscam.dto.ScanResponse;
import com.shield.jobscam.entity.ScanRecord;
import com.shield.jobscam.repository.ScanRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Arrays;
import java.util.List;

@Service
public class ScanService {
    private final ScanRepository repository;
    private final RiskAnalysisService riskAnalysisService;

    public ScanService(ScanRepository repository, RiskAnalysisService riskAnalysisService) {
        this.repository = repository;
        this.riskAnalysisService = riskAnalysisService;
    }

    @Transactional
    public ScanResponse scan(ScanRequest request, String ownerEmail) {
        String type = request.getInputType().toUpperCase();
        String content = request.getContent().trim();

        if ("URL".equals(type) && !content.matches("(?i)^https?://.+")) {
            throw new IllegalArgumentException("Please provide a URL starting with http:// or https://");
        }

        // URL reputation checks will be added through a trusted external API in a later step.
        RiskAnalysisService.Analysis analysis = riskAnalysisService.analyze(content);

        ScanRecord record = new ScanRecord();
        record.setOwnerEmail(ownerEmail);
        record.setInputType(type);
        record.setInputContent(content);
        record.setRiskScore(analysis.score());
        record.setRiskLevel(analysis.level());
        record.setFindings(String.join(" | ", analysis.findings()));
        ScanRecord saved = repository.save(record);

        return toResponse(saved, analysis.findings(), analysis.explanation());
    }

    @Transactional(readOnly = true)
    public List<ScanResponse> getAllScans(String ownerEmail) {
        return repository.findByOwnerEmailIgnoreCaseOrderByCreatedAtDesc(ownerEmail).stream()
                .sorted((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()))
                .map(record -> toResponse(record,
                        record.getFindings() == null || record.getFindings().isBlank()
                                ? List.of() : Arrays.asList(record.getFindings().split(" \\| ")),
                        "Previously saved preliminary scan."))
                .toList();
    }

    @Transactional(readOnly = true)
    public ScanResponse getScan(Long id, String ownerEmail) {
        ScanRecord record = repository.findByIdAndOwnerEmailIgnoreCase(id,ownerEmail)
                .orElseThrow(() -> new IllegalArgumentException("Scan not found: " + id));
        List<String> findings = record.getFindings() == null ? List.of()
                : Arrays.asList(record.getFindings().split(" \\| "));
        return toResponse(record, findings, "Previously saved preliminary scan.");
    }

    private ScanResponse toResponse(ScanRecord record, List<String> findings, String explanation) {
        return new ScanResponse(record.getId(), record.getInputType(), record.getInputContent(), record.getRiskScore(),
                record.getRiskLevel(), findings, explanation, record.getCreatedAt());
    }
}
