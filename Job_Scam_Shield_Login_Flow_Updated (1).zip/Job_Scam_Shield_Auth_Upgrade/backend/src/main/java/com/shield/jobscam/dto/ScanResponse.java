package com.shield.jobscam.dto;
import java.time.LocalDateTime; import java.util.List;
public record ScanResponse(Long id, String inputType, String content, int riskScore, String riskLevel, List<String> findings, String explanation, LocalDateTime createdAt) {}
