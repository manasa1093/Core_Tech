package com.shield.jobscam.controller;

import com.shield.jobscam.dto.ScanRequest;
import com.shield.jobscam.dto.ScanResponse;
import com.shield.jobscam.service.ScanService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/scans")
public class ScanController {
    private final ScanService scanService;

    public ScanController(ScanService scanService) { this.scanService = scanService; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ScanResponse createScan(@Valid @RequestBody ScanRequest request, java.security.Principal principal) {
        return scanService.scan(request,principal.getName());
    }

    @GetMapping
    public List<ScanResponse> getAllScans(java.security.Principal principal) { return scanService.getAllScans(principal.getName()); }

    @GetMapping("/{id}")
    public ScanResponse getScan(@PathVariable Long id, java.security.Principal principal) { return scanService.getScan(id,principal.getName()); }
}
