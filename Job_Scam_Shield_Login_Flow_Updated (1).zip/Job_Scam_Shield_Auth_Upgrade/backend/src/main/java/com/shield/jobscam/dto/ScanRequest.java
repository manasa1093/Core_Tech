package com.shield.jobscam.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class ScanRequest {
    @NotBlank
    @Pattern(regexp = "(?i)TEXT|URL", message = "inputType must be TEXT or URL")
    private String inputType;

    @NotBlank
    @Size(max = 20000, message = "Input must be 20,000 characters or fewer")
    private String content;

    public String getInputType() { return inputType; }
    public void setInputType(String inputType) { this.inputType = inputType; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
}
