package com.shield.jobscam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobScamShieldApplication {
    public static void main(String[] args) {
        SpringApplication.run(JobScamShieldApplication.class, args);
    }
}
