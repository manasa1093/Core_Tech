
package com.shield.jobscam.config;
import org.springframework.context.annotation.*; import org.springframework.security.config.annotation.web.builders.HttpSecurity; import org.springframework.security.config.http.SessionCreationPolicy; import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.security.web.SecurityFilterChain; import org.springframework.web.cors.CorsConfiguration; import java.util.List;
@Configuration public class SecurityConfig {
 @Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
 @Bean SecurityFilterChain filter(HttpSecurity http)throws Exception {http.cors(c->c.configurationSource(req->{CorsConfiguration x=new CorsConfiguration();x.setAllowedOrigins(List.of("http://localhost:5173","http://127.0.0.1:5173"));x.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));x.setAllowedHeaders(List.of("*"));x.setAllowCredentials(true);return x;})).csrf(c->c.disable()).authorizeHttpRequests(a->a.requestMatchers("/api/auth/**").permitAll().anyRequest().authenticated()).sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED));return http.build();}
}
