
package com.shield.jobscam.repository; import com.shield.jobscam.entity.ScanRecord; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List; import java.util.Optional;
public interface ScanRepository extends JpaRepository<ScanRecord,Long>{List<ScanRecord> findByOwnerEmailIgnoreCaseOrderByCreatedAtDesc(String email);Optional<ScanRecord> findByIdAndOwnerEmailIgnoreCase(Long id,String email);}
