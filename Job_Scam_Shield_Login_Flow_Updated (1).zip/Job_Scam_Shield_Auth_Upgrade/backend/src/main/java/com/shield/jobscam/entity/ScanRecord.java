package com.shield.jobscam.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "scan_records")
public class ScanRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 20)
    private String inputType;

    @Column(nullable = false, columnDefinition = "LONGTEXT")
    private String inputContent;

    private int riskScore;

    @Column(nullable = false, length = 30)
    private String riskLevel;

    @Column(columnDefinition = "TEXT")
    private String findings;

    private LocalDateTime createdAt;
    @Column private String ownerEmail;
    public String getOwnerEmail(){return ownerEmail;} public void setOwnerEmail(String v){ownerEmail=v;}

    @PrePersist
    public void onCreate() { createdAt = LocalDateTime.now(); }

    public Long getId() { return id; }
    public String getInputType() { return inputType; }
    public void setInputType(String inputType) { this.inputType = inputType; }
    public String getInputContent() { return inputContent; }
    public void setInputContent(String inputContent) { this.inputContent = inputContent; }
    public int getRiskScore() { return riskScore; }
    public void setRiskScore(int riskScore) { this.riskScore = riskScore; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public String getFindings() { return findings; }
    public void setFindings(String findings) { this.findings = findings; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
